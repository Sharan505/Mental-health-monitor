import json


with open('response.json', 'r') as file:
    json_data = file.read()

parsed_data = json.loads(json_data)
mentalTwoYears=80     #Children 1 to 2 years: 80bpm
mentalFourYears=70    #Children 3 to 4 years: 70bpm
mentalSixYears=65     #Children 5 to 6 years: 65bpm
mentalNineYears=60    #Children 7 to 9 years: 60bpm
mentalTenAbove=60     #Above 10 years: 60bpm


values = [entry['value'] for entry in parsed_data['heart_minutes']]
print(values)